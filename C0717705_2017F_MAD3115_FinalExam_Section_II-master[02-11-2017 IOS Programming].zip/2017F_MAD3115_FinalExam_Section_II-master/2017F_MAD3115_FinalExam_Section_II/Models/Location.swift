//
//  Location.swift
//  2017F_MAD3115_FinalExam_Section_II
//
//  Created by moxDroid on 2017-11-02.
//  Copyright © 2017 moxDroid. All rights reserved.
//  Roll No.    : C0717705
//  Name        : Nirav Bavishi

import Foundation


class Location
{
 
    
    var locationId : String!
    var locationTitle : String!
    var latitude : Double!
    var longitude : Double!
    
  
    
    init() {
        
        self.locationId = ""
        self.locationTitle = ""
        self.latitude = 0.00000
        self.longitude = -0.00000
        
    }
    
    
    init(locationId : String, locationTitle : String, latitude : Double, longitude : Double){
        
        self.locationId = locationId
        self.locationTitle = locationTitle
        self.latitude = latitude
        self.longitude = longitude
        
    }
    
    
        
    
    

    
}
