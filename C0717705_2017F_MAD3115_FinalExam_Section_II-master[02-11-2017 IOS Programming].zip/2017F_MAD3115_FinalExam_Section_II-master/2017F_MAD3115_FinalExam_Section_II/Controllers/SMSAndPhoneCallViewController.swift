//
//  ViewController.swift
//  2017F_MAD3115_FinalExam_Section_II
//
//  Created by moxDroid on 2017-11-02.
//  Copyright © 2017 moxDroid. All rights reserved.
//  Roll No.    : C0717705
//  Name        : Nirav Bavishi

import UIKit
import MessageUI

class SMSAndPhoneCallViewController: UIViewController, MFMessageComposeViewControllerDelegate{
   
    
    
    @IBOutlet weak var txtFieldPhoneNumber: UITextField!
    @IBOutlet weak var txtFieldMessage: UITextField!
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    
    
    
    @IBAction func btnSendSMSTapped(_ sender: UIButton) {
    
        if MFMessageComposeViewController.canSendText() {
            
            let composeVC = MFMessageComposeViewController()
            composeVC.messageComposeDelegate = self
            
            // Configure the fields of the interface.
            composeVC.recipients = [txtFieldPhoneNumber.text!]
            composeVC.body = txtFieldMessage.text
            
            // Present the view controller modally.
            self.present(composeVC, animated: true, completion: nil)
            
        }
    
    }
    
    
    
    func messageComposeViewController(_ controller: MFMessageComposeViewController, didFinishWith result: MessageComposeResult) {
        
        
        switch result {
        case .sent:
            print("Success")
            alertShow(message: "Message Sent Successfully")
            self.dismiss(animated: true, completion: nil)
        
        case .failed:
            print("Fail")
            alertShow(message: "Fail To Sent Message")
            self.dismiss(animated: true, completion: nil)
        
        case .cancelled:
            print("Cancelled")
            alertShow(message: "Message Canceled")
            self.dismiss(animated: true, completion: nil)
            
        default:
            self.dismiss(animated: true, completion: nil)
        }
        
        
    }
    
    
    @IBAction func btnCallTapped(_ sender: UIButton) {
        
        
        
//        if txtFieldPhoneNumber.text != nil {
//
//            let url : String = "tel://\(String(describing: txtFieldPhoneNumber.text))"
//
//            UIApplication.shared.openURL(NSURL(string: url)! as URL)
//        }
//        else {
//
//            alertShow(message: "Enter Phone Number")
//
//        }
        

        if let url = URL(string: "tel://\(String(describing: txtFieldPhoneNumber.text))"), UIApplication.shared.canOpenURL(url){
            if #available(iOS 10, *)
            {
                UIApplication.shared.open(url)
            }
            else
            {
                UIApplication.shared.openURL(url)
            }
        }
                else {
        
                    alertShow(message: "Enter Phone Number")
        
                }
        
    
    
    }
    
    
    func alertShow(message : String){
        
        let alert = UIAlertController(title: "Message", message: message, preferredStyle: .alert)
        
        alert.addAction(UIAlertAction(title: "Ok", style: .default, handler: nil))
        
        self.present(alert, animated: true, completion: nil)
        
    }
    
    
}

