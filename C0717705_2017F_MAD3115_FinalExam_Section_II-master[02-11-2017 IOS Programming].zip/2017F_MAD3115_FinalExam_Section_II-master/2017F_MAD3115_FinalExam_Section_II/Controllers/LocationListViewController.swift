//
//  LocationListViewController.swift
//  2017F_MAD3115_FinalExam_Section_II
//
//  Created by moxDroid on 2017-11-02.
//  Copyright © 2017 moxDroid. All rights reserved.
//  Roll No.    : C0717705
//  Name        : Nirav Bavishi
import UIKit

class LocationListViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
  
    
    
    
    
    @IBOutlet weak var tblView: UITableView!
    
    
    var locationIndex : Int!
    
    
    var LocationArray = [Location]()
    
   
    var location1 = Location(locationId: "Location1", locationTitle: "Hearts Desire", latitude: 45.266609, longitude: -75.716660)
    
    var location2 = Location(locationId: "Location2", locationTitle: "Saanich, Victoria", latitude: 48.459377, longitude: -123.378014)
    
    var location3 = Location(locationId: "Location3", locationTitle: "Nepean, Ottawa", latitude: 45.334904, longitude: -75.724098)
    
    var location4 = Location(locationId: "Location4", locationTitle: "Wolseley, Winnipeg", latitude: 49.883354, longitude: -97.170120)
    
    var location5 = Location(locationId: "Location5", locationTitle: "Aspen Gardens", latitude: 56.718266, longitude: -111.384216)
    
    

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        
        self.tblView.delegate = self
        self.tblView.dataSource = self
        
        
        LocationArray.append(location1)
        LocationArray.append(location2)
        LocationArray.append(location3)
        LocationArray.append(location4)
        LocationArray.append(location5)
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
    
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return LocationArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "cellLocation")! //1.
        
        let text = "Location \(indexPath.row+1) : " + LocationArray[indexPath.row].locationTitle //2.
        
        cell.textLabel?.text = text //3.
        
        return cell //4.
        
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        
        if indexPath.row == 0 {
            
            locationIndex = 0
            
            
            
        } else if indexPath.row == 1 {
            
            locationIndex = 1
            
        }else if indexPath.row == 2 {
            
            locationIndex = 2
            
        }else if indexPath.row == 3 {
            
            locationIndex = 3
            
        }else if indexPath.row == 4 {
            
            locationIndex = 4
            
        }
        performSegue(withIdentifier: "TableToMap", sender: self)
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let ShowLocation = segue.destination as! ShowLocationOnMapViewController
        
        ShowLocation.LocationShow = LocationArray[locationIndex]
        
    }
    
    

}
